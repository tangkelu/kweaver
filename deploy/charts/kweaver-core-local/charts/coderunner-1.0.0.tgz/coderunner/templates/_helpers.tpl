{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "coderunner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "coderunner.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "coderunner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "coderunner.labels" -}}
helm.sh/chart: {{ include "coderunner.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "coderunner.imageRegistry" -}}
{{- $globalImage := ( .Values.global | default dict ).image | default dict -}}
{{- coalesce $globalImage.registry .Values.image.registry -}}
{{- end -}}

{{- define "coderunner.depServices" -}}
{{- $globalDeps := ( .Values.global | default dict ).depServices | default dict -}}
{{- toYaml (mergeOverwrite (deepCopy .Values.depServices) $globalDeps) -}}
{{- end -}}

{{- define "coderunner.env" -}}
{{- $globalEnv := ( .Values.global | default dict ).env | default dict -}}
{{- toYaml (mergeOverwrite (deepCopy .Values.env) $globalEnv) -}}
{{- end -}}

{{- define "coderunner.replicaCount" -}}
{{- coalesce (( .Values.global | default dict ).replicaCount) .Values.replicaCount -}}
{{- end -}}

{{- define "coderunner.imagePullSecrets" -}}
{{- if .Values.imagePullSecrets -}}
{{- toYaml .Values.imagePullSecrets -}}
{{- else -}}
{{- toYaml ((( .Values.global | default dict ).imagePullSecrets) | default list) -}}
{{- end -}}
{{- end -}}

{{- define "rds.realDatabase" -}}
{{- $deps := include "coderunner.depServices" . | fromYaml -}}
{{- printf "%s%s" $deps.rds.system_id $deps.rds.database -}}
{{- end -}}

{{/*
Define the fullname for dataflowtools
*/}}
{{- define "dataflowtools.fullname" -}}
dataflowtools 
{{- end -}}
